import numpy as np

input_path = './test/input.txt'

with open(input_path, 'w') as f:
    random_array = np.array
    f.write()
