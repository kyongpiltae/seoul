stat-learning
=============

Notes and exercise attempts for "An Introduction to Statistical Learning"

http://www.statlearning.com
http://statlearning.class.stanford.edu/

"(*)" means I am not sure about the answer

Try out RStudio (www.RStudio.com) as an R IDE with the knitr package.

Pull requests gladly accepted. If a pull request is too much effort, please at least file a new issue. :)

Visit http://asadoughi.github.io/stat-learning for an index of exercise solutions.
