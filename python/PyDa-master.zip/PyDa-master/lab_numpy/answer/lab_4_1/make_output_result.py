import numpy as numpy
import num
from lab_4_1 import *

input_path = './test/input.txt'
output_path = './test/output.txt'
answer_path = './test/answer.txt'
logfile_path = 'log.txt'

f = open(input_path, 'w')

for i in 


if __name__ == '__main__':
