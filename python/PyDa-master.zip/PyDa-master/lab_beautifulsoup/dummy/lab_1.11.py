import nltk
nltk.download("book", quiet=True)
from nltk.book import *

print(nltk.corpus.gutenberg.fileids())

