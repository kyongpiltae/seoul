# PyDA
Python for Data Analysis. <br>

## date
| Date | Title |
|------|-------|
| 2020-01-10 am | lab-numpy |
| 2020-01-10 pm | lab-pandas |
| 2020-01-13 am | lab-advanced(numpy + pandas) |
| 2020-01-14 am | lab-matplotlib |
| 2020-01-15 am | lab-sklearn |
| 2020-01-16 am | lab-Data Prepprocessing |
| 2020-01-17 am | lab-BeautifulSoup |
| 2020-01-17 am | final exam |

<hr>
