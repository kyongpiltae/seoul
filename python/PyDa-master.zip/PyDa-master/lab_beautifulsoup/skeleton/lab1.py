from bs4 import BeautifulSoup
import requests


def get_rank(url):

    return rank


if __name__ == '__main__':
    url = 'https://datalab.naver.com/'
    rank = get_rank(url)
    print(rank)
